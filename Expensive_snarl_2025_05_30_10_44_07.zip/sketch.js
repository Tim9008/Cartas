let cartas = [];
let valores = [];
let selecionadas = [];
let acertadas = [];

function setup() {
  createCanvas(400, 400);
  let pares = [1, 1, 2, 2, 3, 3, 4, 4];
  valores = shuffle(pares);
  for (let i = 0; i < 8; i++) cartas[i] = false;
}

function draw() {
  background(220);
  for (let i = 0; i < 8; i++) {
    let x = (i % 4) * 100;
    let y = floor(i / 4) * 200;
    fill(cartas[i] || acertadas[i] ? 255 : 100);
    rect(x + 10, y + 10, 80, 180);
    if (cartas[i] || acertadas[i]) {
      fill(0);
      textSize(32);
      textAlign(CENTER, CENTER);
      text(valores[i], x + 50, y + 100);
    }
  }
}

function mousePressed() {
  for (let i = 0; i < 8; i++) {
    let x = (i % 4) * 100;
    let y = floor(i / 4) * 200;
    if (mouseX > x + 10 && mouseX < x + 90 && mouseY > y + 10 && mouseY < y + 190 && !acertadas[i]) {
      if (!cartas[i]) {
        cartas[i] = true;
        selecionadas.push(i);
        if (selecionadas.length == 2) {
          let [a, b] = selecionadas;
          if (valores[a] == valores[b]) {
            acertadas[a] = acertadas[b] = true;
          } else {
            setTimeout(() => { cartas[a] = cartas[b] = false; }, 500);
          }
          selecionadas = [];
        }
      }
    }
  }
}
